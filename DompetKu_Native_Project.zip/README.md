# DompetKu

Aplikasi pencatatan keuangan pribadi Android native (Kotlin + Jetpack Compose), berjalan offline dengan penyimpanan SQLite lokal.

## Fitur awal
- Ringkasan saldo, pemasukan, dan pengeluaran
- Grafik ringkasan arus kas
- Tambah transaksi dan kategori bebas (termasuk Utang/Piutang)
- Pencarian transaksi
- Pengaturan anggaran bulanan
- Ekspor data transaksi ke Excel `.xlsx`
- Build APK otomatis melalui GitHub Actions

## Build
Jalankan workflow **Build DompetKu APK** dari tab Actions. APK debug tersedia sebagai artifact `DompetKu-APK` setelah build berhasil.
