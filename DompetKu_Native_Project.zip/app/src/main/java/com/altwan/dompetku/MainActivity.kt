package com.altwan.dompetku

import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Wallet
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

private val Bg = Color(0xFF10131B)
private val Panel = Color(0xFF1B202B)
private val Mint = Color(0xFF62D6AE)
private val Red = Color(0xFFFF7777)
private val Muted = Color(0xFF9AA4B5)
private val idr = NumberFormat.getCurrencyInstance(Locale("id", "ID")).apply { maximumFractionDigits = 0 }

data class Tx(val id: Long, val title: String, val amount: Long, val type: String, val category: String, val date: String)

class Store(c: android.content.Context) : SQLiteOpenHelper(c, "dompetku.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE tx(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,amount INTEGER,type TEXT,category TEXT,date TEXT)")
        db.execSQL("CREATE TABLE settings(k TEXT PRIMARY KEY,v TEXT)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun add(title:String, amount:Long, type:String, category:String) {
        val v=ContentValues().apply { put("title",title);put("amount",amount);put("type",type);put("category",category);put("date",SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())) }
        writableDatabase.insert("tx",null,v)
    }
    fun all(): List<Tx> {
        val out=mutableListOf<Tx>(); readableDatabase.rawQuery("SELECT * FROM tx ORDER BY id DESC",null).use { c -> while(c.moveToNext()) out += Tx(c.getLong(0),c.getString(1),c.getLong(2),c.getString(3),c.getString(4),c.getString(5)) }; return out
    }
    fun replaceAll(items: List<Tx>) {
        writableDatabase.beginTransaction()
        try { writableDatabase.delete("tx", null, null); items.forEach { item ->
            val v=ContentValues().apply { put("title",item.title);put("amount",item.amount);put("type",item.type);put("category",item.category);put("date",item.date) }
            writableDatabase.insert("tx",null,v)
        }; writableDatabase.setTransactionSuccessful() } finally { writableDatabase.endTransaction() }
    }
    fun budget():Long = readableDatabase.rawQuery("SELECT v FROM settings WHERE k='budget'",null).use { if(it.moveToFirst()) it.getString(0).toLongOrNull()?:0L else 0L }
    fun setBudget(v:Long) { val cv=ContentValues().apply { put("k","budget");put("v",v.toString()) }; writableDatabase.insertWithOnConflict("settings",null,cv,SQLiteDatabase.CONFLICT_REPLACE) }
}

class MainActivity : ComponentActivity() {
    private lateinit var store: Store
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); store=Store(this); setContent { DompetApp(store) } }
}

@Composable fun DompetApp(store: Store) {
    var rows by remember { mutableStateOf(store.all()) }
    var query by remember { mutableStateOf("") }
    var showAdd by remember { mutableStateOf(false) }
    var showBudget by remember { mutableStateOf(false) }
    var budget by remember { mutableStateOf(store.budget().toString()) }
    val context = androidx.compose.ui.platform.LocalContext.current
    val saveXlsx = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) { uri ->
        if(uri!=null) runCatching { context.contentResolver.openOutputStream(uri)?.use { writeWorkbook(it, rows) } }
    }
    val restoreXlsx = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if(uri!=null) runCatching { context.contentResolver.openInputStream(uri)?.use { store.replaceAll(readWorkbook(it)); rows=store.all() } }
    }
    val income=rows.filter{it.type=="Masuk"}.sumOf{it.amount}; val expense=rows.filter{it.type=="Keluar"}.sumOf{it.amount}
    val filtered=rows.filter { it.title.contains(query,true)||it.category.contains(query,true) }
    MaterialTheme(colorScheme=darkColorScheme(primary=Mint,background=Bg,surface=Panel,onBackground=Color.White,onSurface=Color.White)) {
        Scaffold(containerColor=Bg, floatingActionButton={ FloatingActionButton(onClick={showAdd=true},containerColor=Mint,contentColor=Bg){ Icon(Icons.Default.Add,"Tambah transaksi") } }) { pad ->
            LazyColumn(Modifier.fillMaxSize().padding(pad).padding(horizontal=18.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
                item { Row(Modifier.fillMaxWidth().padding(top=18.dp),verticalAlignment=Alignment.CenterVertically){ Icon(Icons.Default.Wallet,null,tint=Mint,modifier=Modifier.size(30.dp)); Spacer(Modifier.width(10.dp)); Column { Text("DompetKu",fontSize=25.sp,fontWeight=FontWeight.Bold); Text("Catatan keuangan pribadi",color=Muted,fontSize=12.sp) } } }
                item { Card(colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(22.dp)) { Column(Modifier.padding(18.dp)) { Text("TOTAL SALDO",color=Muted,fontSize=12.sp); Text(idr.format(income-expense),fontSize=27.sp,fontWeight=FontWeight.Bold); Spacer(Modifier.height(14.dp)); Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){ Summary("Pemasukan",income,Mint); Summary("Pengeluaran",expense,Red) } } } }
                item { Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) { StatCard("Anggaran bulanan",if(budget.toLongOrNull()==null||budget.toLong()==0L) "Belum diatur" else idr.format(budget.toLong()),Modifier.weight(1f)){showBudget=true}; StatCard("Utang / Piutang",rows.count{it.category.contains("utang",true)||it.category.contains("piutang",true)}.toString()+" catatan",Modifier.weight(1f)){} } }
                item { Card(colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(18.dp)){ Column(Modifier.padding(16.dp)){ Text("Ringkasan arus kas",fontWeight=FontWeight.SemiBold); Spacer(Modifier.height(10.dp)); CashChart(income,expense); Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Masuk",color=Mint,fontSize=12.sp);Text("Keluar",color=Red,fontSize=12.sp)} } } }
                item { Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){ Text("Transaksi",fontSize=19.sp,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f)); TextButton(onClick={saveXlsx.launch("DompetKu_Backup.xlsx")}){Text("Backup")}; TextButton(onClick={restoreXlsx.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))}){Text("Pulihkan")} }; OutlinedTextField(query,{query=it},modifier=Modifier.fillMaxWidth(),placeholder={Text("Cari transaksi...")},leadingIcon={Icon(Icons.Default.Search,null)},singleLine=true,shape=RoundedCornerShape(14.dp)) }
                if(filtered.isEmpty()) item { Text("Belum ada transaksi. Tekan tombol + untuk mencatat.",color=Muted,modifier=Modifier.padding(vertical=20.dp)) }
                items(filtered,key={it.id}) { tx -> TransactionRow(tx) }
                item { Spacer(Modifier.height(80.dp)) }
            }
        }
        if(showAdd) AddDialog(onDismiss={showAdd=false},onSave={t,a,ty,cat->store.add(t,a,ty,cat);rows=store.all();showAdd=false})
        if(showBudget) AlertDialog(onDismissRequest={showBudget=false},title={Text("Anggaran bulanan")},text={OutlinedTextField(budget,{budget=it},label={Text("Anggaran (Rp)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number))},confirmButton={TextButton(onClick={store.setBudget(budget.toLongOrNull()?:0);showBudget=false}){Text("Simpan")}},dismissButton={TextButton(onClick={showBudget=false}){Text("Batal")}})
    }
}

@Composable fun Summary(label:String,value:Long,color:Color){ Column { Text(label,color=Muted,fontSize=12.sp); Text(idr.format(value),color=color,fontWeight=FontWeight.Bold,fontSize=16.sp) } }
@Composable fun StatCard(title:String,value:String,modifier:Modifier,onClick:()->Unit){ Card(modifier.clickable{onClick()},colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(14.dp)){Text(title,color=Muted,fontSize=11.sp);Spacer(Modifier.height(7.dp));Text(value,fontWeight=FontWeight.Bold,fontSize=14.sp)}} }
@Composable fun CashChart(income:Long,expense:Long){ val max=(maxOf(income,expense,1L)).toFloat(); Canvas(Modifier.fillMaxWidth().height(105.dp)){ val bar= size.width*.22f; val base=size.height-8; val h1=(income/max)*(size.height-18); val h2=(expense/max)*(size.height-18); drawRoundRect(Mint,androidx.compose.ui.geometry.Offset(size.width*.22f,base-h1),androidx.compose.ui.geometry.Size(bar,h1),androidx.compose.ui.geometry.CornerRadius(14f)); drawRoundRect(Red,androidx.compose.ui.geometry.Offset(size.width*.60f,base-h2),androidx.compose.ui.geometry.Size(bar,h2),androidx.compose.ui.geometry.CornerRadius(14f)) } }
@Composable fun TransactionRow(tx:Tx){ Card(colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(16.dp)){Row(Modifier.fillMaxWidth().padding(14.dp),verticalAlignment=Alignment.CenterVertically){ Box(Modifier.size(40.dp).background(if(tx.type=="Masuk") Color(0x223ED7A3) else Color(0x22FF7777),CircleShape),contentAlignment=Alignment.Center){Icon(if(tx.type=="Masuk") Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,null,tint=if(tx.type=="Masuk") Mint else Red)}; Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(tx.title,fontWeight=FontWeight.SemiBold);Text("${tx.category} • ${tx.date}",color=Muted,fontSize=11.sp)};Text((if(tx.type=="Masuk") "+" else "-")+idr.format(tx.amount),color=if(tx.type=="Masuk") Mint else Red,fontWeight=FontWeight.Bold,fontSize=13.sp)} } }
@Composable fun AddDialog(onDismiss:()->Unit,onSave:(String,Long,String,String)->Unit){ var title by remember{mutableStateOf("")};var amount by remember{mutableStateOf("")};var type by remember{mutableStateOf("Keluar")};var category by remember{mutableStateOf("Makan")}; AlertDialog(onDismissRequest=onDismiss,title={Text("Tambah transaksi")},text={Column(verticalArrangement=Arrangement.spacedBy(9.dp)){OutlinedTextField(title,{title=it},label={Text("Nama transaksi")},singleLine=true);OutlinedTextField(amount,{amount=it},label={Text("Jumlah (Rp)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),singleLine=true);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){FilterChip(type=="Keluar",{type="Keluar"},label={Text("Pengeluaran")});FilterChip(type=="Masuk",{type="Masuk"},label={Text("Pemasukan")})};OutlinedTextField(category,{category=it},label={Text("Kategori (Makan, Gaji, Utang, Piutang...)")},singleLine=true)}},confirmButton={TextButton(onClick={val n=amount.toLongOrNull();if(title.isNotBlank()&&n!=null&&n>0)onSave(title,n,type,category)} ){Text("Simpan")}},dismissButton={TextButton(onClick=onDismiss){Text("Batal")}}) }

private fun xml(s:String)=s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;")
private fun decodeXml(s:String)=s.replace("&amp;","&").replace("&lt;","<").replace("&gt;",">").replace("&quot;","\"").replace("&apos;","'")
private fun readWorkbook(input:java.io.InputStream): List<Tx> {
    var sheet=""
    java.util.zip.ZipInputStream(input).use { zip -> var e=zip.nextEntry; while(e!=null){ if(e.name=="xl/worksheets/sheet1.xml") sheet=zip.readBytes().toString(Charsets.UTF_8); e=zip.nextEntry } }
    val rows=Regex("<row[^>]*>(.*?)</row>").findAll(sheet).drop(1)
    return rows.mapNotNull { m ->
        val cells=Regex("<t>(.*?)</t>").findAll(m.groupValues[1]).map{decodeXml(it.groupValues[1])}.toList()
        if(cells.size>=6) Tx(0,cells[1],cells[2].toLongOrNull()?:0L,cells[3],cells[4],cells[5]) else null
    }.toList()
}

private fun writeWorkbook(out:java.io.OutputStream, rows:List<Tx>){
    val headers=listOf("ID","Nama","Jumlah_Rp","Jenis","Kategori","Tanggal")
    val all=listOf(headers)+rows.map{listOf(it.id.toString(),it.title,it.amount.toString(),it.type,it.category,it.date)}
    val sheet=buildString { append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>"); all.forEachIndexed{ri,row->append("<row r=\"${ri+1}\">");row.forEachIndexed{ci,v->val col=('A'.code+ci).toChar();append("<c r=\"$col${ri+1}\" t=\"inlineStr\"><is><t>${xml(v)}</t></is></c>")};append("</row>")};append("</sheetData></worksheet>") }
    ZipOutputStream(out).use { z -> fun entry(n:String,s:String){z.putNextEntry(ZipEntry(n));z.write(s.toByteArray(Charsets.UTF_8));z.closeEntry()}; entry("[Content_Types].xml","<?xml version=\"1.0\" encoding=\"UTF-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/></Types>");entry("_rels/.rels","<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");entry("xl/workbook.xml","<?xml version=\"1.0\" encoding=\"UTF-8\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\"Transaksi\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>");entry("xl/_rels/workbook.xml.rels","<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/></Relationships>");entry("xl/worksheets/sheet1.xml",sheet) }
}
