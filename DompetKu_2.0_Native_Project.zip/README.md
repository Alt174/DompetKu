# DompetKu 2.0

Aplikasi keuangan pribadi Android native dengan Kotlin + Jetpack Compose.
- Dashboard saldo dan arus kas
- Pemasukan/pengeluaran, pencarian, hapus transaksi
- Kategori yang dapat ditambah dan dihapus
- Ringkasan laporan per kategori
- Anggaran bulanan
- Ekspor/impor workbook XLSX sederhana
- Penyimpanan lokal SQLite, tanpa koneksi internet

Build melalui GitHub Actions dengan `gradle assembleDebug`.
