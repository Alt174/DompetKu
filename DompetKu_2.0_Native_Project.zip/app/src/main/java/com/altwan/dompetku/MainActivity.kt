package com.altwan.dompetku

import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

private val Bg = Color(0xFF0D111B)
private val Surface1 = Color(0xFF171E2B)
private val Surface2 = Color(0xFF202A3A)
private val Accent = Color(0xFF67E0B5)
private val Income = Color(0xFF62D6A8)
private val Expense = Color(0xFFFF777F)
private val Muted = Color(0xFF9AA8BA)
private val idr = NumberFormat.getCurrencyInstance(Locale("id", "ID")).apply { maximumFractionDigits = 0 }

data class Tx(val id: Long, val title: String, val amount: Long, val type: String, val category: String, val date: String)

class Store(c: android.content.Context) : SQLiteOpenHelper(c, "dompetku.db", null, 2) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE tx(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,amount INTEGER NOT NULL,type TEXT NOT NULL,category TEXT NOT NULL,date TEXT NOT NULL)")
        db.execSQL("CREATE TABLE settings(k TEXT PRIMARY KEY,v TEXT)")
        putSetting(db, "categories", "Makanan,Transportasi,Belanja,Tagihan,Kesehatan,Pendidikan,Gaji,Bisnis,Hadiah,Utang,Piutang,Lainnya")
        putSetting(db, "budget", "0")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY,v TEXT)")
            putSetting(db, "categories", "Makanan,Transportasi,Belanja,Tagihan,Kesehatan,Pendidikan,Gaji,Bisnis,Hadiah,Utang,Piutang,Lainnya")
            putSetting(db, "budget", "0")
        }
    }
    private fun putSetting(db: SQLiteDatabase, k: String, v: String) {
        val cv = ContentValues().apply { put("k", k); put("v", v) }
        db.insertWithOnConflict("settings", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun setting(k: String, fallback: String = ""): String =
        readableDatabase.rawQuery("SELECT v FROM settings WHERE k=?", arrayOf(k)).use { if (it.moveToFirst()) it.getString(0) else fallback }
    fun setSetting(k: String, v: String) {
        val cv = ContentValues().apply { put("k", k); put("v", v) }
        writableDatabase.insertWithOnConflict("settings", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun add(title: String, amount: Long, type: String, category: String) {
        val cv = ContentValues().apply {
            put("title", title); put("amount", amount); put("type", type)
            put("category", category); put("date", SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()))
        }
        writableDatabase.insert("tx", null, cv)
    }
    fun all(): List<Tx> {
        val out = mutableListOf<Tx>()
        readableDatabase.rawQuery("SELECT * FROM tx ORDER BY id DESC", null).use { c ->
            while (c.moveToNext()) out += Tx(c.getLong(0), c.getString(1), c.getLong(2), c.getString(3), c.getString(4), c.getString(5))
        }
        return out
    }
    fun delete(id: Long) { writableDatabase.delete("tx", "id=?", arrayOf(id.toString())) }
    fun replaceAll(items: List<Tx>) {
        writableDatabase.beginTransaction()
        try {
            writableDatabase.delete("tx", null, null)
            items.forEach { item ->
                val cv = ContentValues().apply {
                    put("title", item.title); put("amount", item.amount); put("type", item.type)
                    put("category", item.category); put("date", item.date)
                }
                writableDatabase.insert("tx", null, cv)
            }
            writableDatabase.setTransactionSuccessful()
        } finally { writableDatabase.endTransaction() }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = Store(this)
        setContent { DompetApp(store) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DompetApp(store: Store) {
    var rows by remember { mutableStateOf(store.all()) }
    var categories by remember { mutableStateOf(store.setting("categories", "Makanan,Transportasi,Belanja,Gaji,Utang,Piutang,Lainnya").split(",").filter { it.isNotBlank() }) }
    var budget by remember { mutableStateOf(store.setting("budget", "0")) }
    var query by remember { mutableStateOf("") }
    var tab by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var showCategories by remember { mutableStateOf(false) }
    var showBudget by remember { mutableStateOf(false) }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) { uri ->
        if (uri != null) runCatching { ctx.contentResolver.openOutputStream(uri)?.use { writeWorkbook(it, rows) } }
    }
    val import = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching {
            val restored = ctx.contentResolver.openInputStream(uri)?.use { readWorkbook(it) } ?: emptyList()
            store.replaceAll(restored); rows = store.all()
        }
    }
    val income = rows.filter { it.type == "Masuk" }.sumOf { it.amount }
    val expense = rows.filter { it.type == "Keluar" }.sumOf { it.amount }
    val balance = income - expense
    val filtered = rows.filter { it.title.contains(query, true) || it.category.contains(query, true) || it.date.contains(query, true) }
    MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Surface1, onBackground = Color.White, onSurface = Color.White)) {
        Scaffold(
            containerColor = Bg,
            topBar = {
                TopAppBar(
                    title = { Column { Text("DompetKu", fontWeight = FontWeight.Bold); Text(listOf("Ringkasan keuangan", "Semua transaksi", "Laporan keuangan", "Pengaturan")[tab], color = Muted, fontSize = 11.sp) } },
                    actions = { IconButton(onClick = { export.launch("DompetKu_Backup.xlsx") }) { Icon(Icons.Default.FileDownload, "Ekspor Excel", tint = Accent) } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Surface1, contentColor = Accent) {
                    listOf(Icons.Default.Home to "Beranda", Icons.Default.ReceiptLong to "Transaksi", Icons.Default.BarChart to "Laporan", Icons.Default.Settings to "Setelan").forEachIndexed { i, pair ->
                        NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(pair.first, null) }, label = { Text(pair.second, fontSize = 10.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Accent, selectedTextColor = Accent, indicatorColor = Surface2, unselectedIconColor = Muted, unselectedTextColor = Muted))
                    }
                }
            },
            floatingActionButton = { if (tab <= 1) FloatingActionButton(onClick = { showAdd = true }, containerColor = Accent, contentColor = Bg) { Icon(Icons.Default.Add, "Tambah transaksi") } }
        ) { padding ->
            when (tab) {
                0 -> HomeScreen(rows, income, expense, balance, budget, Modifier.padding(padding), onAdd = { showAdd = true }, onTransactions = { tab = 1 }, onBudget = { showBudget = true })
                1 -> Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), placeholder = { Text("Cari transaksi, kategori, tanggal") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true, shape = RoundedCornerShape(16.dp))
                    Spacer(Modifier.height(10.dp))
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        if (filtered.isEmpty()) item { EmptyState("Belum ada transaksi", "Tekan tombol + untuk mencatat pemasukan atau pengeluaran.") }
                        items(filtered, key = { it.id }) { tx -> TransactionCard(tx, onDelete = { store.delete(tx.id); rows = store.all() }) }
                        item { Spacer(Modifier.height(80.dp)) }
                    }
                }
                2 -> ReportScreen(income, expense, rows, Modifier.padding(padding))
                else -> SettingsScreen(
                    Modifier.padding(padding),
                    onCategories = { showCategories = true },
                    onBudget = { showBudget = true },
                    onExport = { export.launch("DompetKu_Backup.xlsx") },
                    onImport = { import.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/octet-stream")) }
                )
            }
        }
        if (showAdd) AddTransactionDialog(categories, onDismiss = { showAdd = false }, onSave = { title, amount, type, category ->
            store.add(title, amount, type, category); rows = store.all(); showAdd = false
        })
        if (showCategories) CategoryDialog(categories, onDismiss = { showCategories = false }, onSave = {
            categories = it; store.setSetting("categories", it.joinToString(","))
        })
        if (showBudget) BudgetDialog(budget, onDismiss = { showBudget = false }, onSave = {
            budget = it; store.setSetting("budget", it)
        })
    }
}

@Composable
fun HomeScreen(rows: List<Tx>, income: Long, expense: Long, balance: Long, budget: String, modifier: Modifier = Modifier, onAdd: () -> Unit, onTransactions: () -> Unit, onBudget: () -> Unit) {
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Surface2), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp)) {
                    Text("TOTAL SALDO", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    Text(idr.format(balance), fontSize = 29.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Spacer(Modifier.height(18.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        MoneySummary("Pemasukan", income, Income, Icons.Default.ArrowDownward)
                        MoneySummary("Pengeluaran", expense, Expense, Icons.Default.ArrowUpward)
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                QuickAction("Tambah transaksi", Icons.Default.Add, Modifier.weight(1f), onAdd)
                QuickAction("Anggaran", Icons.Default.PieChart, Modifier.weight(1f), onBudget)
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Surface1), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Arus kas", fontWeight = FontWeight.Bold); Text("Total", color = Muted, fontSize = 12.sp) }
                    Spacer(Modifier.height(14.dp))
                    CashBars(income, expense)
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Masuk ${idr.format(income)}", color = Income, fontSize = 11.sp); Text("Keluar ${idr.format(expense)}", color = Expense, fontSize = 11.sp) }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Transaksi terbaru", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                TextButton(onClick = onTransactions) { Text("Lihat semua") }
            }
        }
        if (rows.isEmpty()) item { EmptyState("Dompet masih kosong", "Mulai catat transaksi pertamamu.") }
        items(rows.take(5), key = { it.id }) { TransactionCard(it, compact = true) {} }
        item { Spacer(Modifier.height(70.dp)) }
    }
}

@Composable
fun MoneySummary(label: String, value: Long, color: Color, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(34.dp).background(color.copy(alpha = .14f), CircleShape), contentAlignment = Alignment.Center) { Icon(icon, null, tint = color, modifier = Modifier.size(18.dp)) }
        Spacer(Modifier.width(8.dp))
        Column { Text(label, color = Muted, fontSize = 11.sp); Text(idr.format(value), color = color, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
    }
}

@Composable
fun QuickAction(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Card(modifier.clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = Surface1), shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = Accent); Spacer(Modifier.width(8.dp)); Text(label, fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
    }
}

@Composable
fun CashBars(income: Long, expense: Long) {
    val max = maxOf(income, expense, 1L).toFloat()
    Canvas(Modifier.fillMaxWidth().height(105.dp)) {
        val bw = size.width * .24f
        val base = size.height - 4f
        val h1 = (income / max) * (size.height - 12f)
        val h2 = (expense / max) * (size.height - 12f)
        drawRoundRect(Income, androidx.compose.ui.geometry.Offset(size.width * .18f, base - h1), androidx.compose.ui.geometry.Size(bw, h1), androidx.compose.ui.geometry.CornerRadius(18f))
        drawRoundRect(Expense, androidx.compose.ui.geometry.Offset(size.width * .58f, base - h2), androidx.compose.ui.geometry.Size(bw, h2), androidx.compose.ui.geometry.CornerRadius(18f))
    }
}

@Composable
fun TransactionCard(tx: Tx, compact: Boolean = false, onDelete: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Surface1), shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.fillMaxWidth().padding(if (compact) 12.dp else 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(40.dp).background((if (tx.type == "Masuk") Income else Expense).copy(alpha = .14f), CircleShape), contentAlignment = Alignment.Center) {
                Icon(if (tx.type == "Masuk") Icons.Default.ArrowDownward else Icons.Default.ArrowUpward, null, tint = if (tx.type == "Masuk") Income else Expense)
            }
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text(tx.title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Text("${tx.category}  •  ${tx.date}", color = Muted, fontSize = 10.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text((if (tx.type == "Masuk") "+" else "−") + idr.format(tx.amount), color = if (tx.type == "Masuk") Income else Expense, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                if (!compact) TextButton(onClick = onDelete, contentPadding = PaddingValues(0.dp)) { Text("Hapus", color = Expense, fontSize = 10.sp) }
            }
        }
    }
}

@Composable
fun ReportScreen(income: Long, expense: Long, rows: List<Tx>, modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Laporan keseluruhan", fontWeight = FontWeight.Bold, fontSize = 20.sp) }
        item { ReportTile("Total pemasukan", income, Income) }
        item { ReportTile("Total pengeluaran", expense, Expense) }
        item { ReportTile("Selisih saldo", income - expense, Accent) }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Surface1), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Pengeluaran per kategori", fontWeight = FontWeight.Bold)
                    val groups = rows.filter { it.type == "Keluar" }.groupBy { it.category }.mapValues { e -> e.value.sumOf { it.amount } }.toList().sortedByDescending { it.second }
                    if (groups.isEmpty()) Text("Belum ada data pengeluaran.", color = Muted, modifier = Modifier.padding(top = 12.dp))
                    groups.forEach { (cat, amount) ->
                        Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text(cat, color = Muted); Text(idr.format(amount), fontWeight = FontWeight.SemiBold) }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(70.dp)) }
    }
}

@Composable
fun ReportTile(title: String, amount: Long, color: Color) {
    Card(colors = CardDefaults.cardColors(containerColor = Surface1), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) { Text(title, color = Muted, fontSize = 12.sp); Text(idr.format(amount), color = color, fontWeight = FontWeight.Bold, fontSize = 20.sp) }
    }
}

@Composable
fun SettingsScreen(modifier: Modifier = Modifier, onCategories: () -> Unit, onBudget: () -> Unit, onExport: () -> Unit, onImport: () -> Unit) {
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Pengaturan", fontWeight = FontWeight.Bold, fontSize = 20.sp) }
        item { SettingRow(Icons.Default.Category, "Kelola kategori", "Tambah, ubah, dan hapus kategori", onCategories) }
        item { SettingRow(Icons.Default.AccountBalanceWallet, "Anggaran bulanan", "Atur batas pengeluaran", onBudget) }
        item { SettingRow(Icons.Default.FileDownload, "Ekspor Excel", "Simpan salinan transaksi .xlsx", onExport) }
        item { SettingRow(Icons.Default.FileUpload, "Impor Excel", "Pulihkan transaksi dari file .xlsx", onImport) }
        item { SettingRow(Icons.Default.Security, "Penyimpanan offline", "Data disimpan lokal di perangkat", {}) }
        item { Spacer(Modifier.height(70.dp)) }
    }
}

@Composable
fun SettingRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, onClick: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = Surface1), shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Accent, modifier = Modifier.size(24.dp))
            Spacer(Modifier.width(13.dp))
            Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.SemiBold); Text(subtitle, color = Muted, fontSize = 11.sp) }
            Icon(Icons.Default.ChevronRight, null, tint = Muted)
        }
    }
}

@Composable
fun EmptyState(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.AccountBalanceWallet, null, tint = Muted, modifier = Modifier.size(42.dp))
        Spacer(Modifier.height(10.dp)); Text(title, fontWeight = FontWeight.Bold)
        Text(subtitle, color = Muted, fontSize = 12.sp)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddTransactionDialog(categories: List<String>, onDismiss: () -> Unit, onSave: (String, Long, String, String) -> Unit) {
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("Keluar") }
    var category by remember { mutableStateOf(categories.firstOrNull() ?: "Lainnya") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Tambah transaksi") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
            OutlinedTextField(title, { title = it }, label = { Text("Nama transaksi") }, singleLine = true)
            OutlinedTextField(amount, { amount = it.filter(Char::isDigit) }, label = { Text("Jumlah (Rp)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(type == "Keluar", { type = "Keluar" }, label = { Text("Pengeluaran") })
                FilterChip(type == "Masuk", { type = "Masuk" }, label = { Text("Pemasukan") })
            }
            var expanded by remember { mutableStateOf(false) }
            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
                OutlinedTextField(category, {}, Modifier.menuAnchor().fillMaxWidth(), readOnly = true, label = { Text("Kategori") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) })
                ExposedDropdownMenu(expanded, { expanded = false }) {
                    categories.forEach { c -> DropdownMenuItem(text = { Text(c) }, onClick = { category = c; expanded = false }) }
                }
            }
        }
    }, confirmButton = { TextButton(onClick = { val n = amount.toLongOrNull(); if (title.isNotBlank() && n != null && n > 0) onSave(title.trim(), n, type, category) }) { Text("Simpan") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } })
}

@Composable
fun CategoryDialog(categories: List<String>, onDismiss: () -> Unit, onSave: (List<String>) -> Unit) {
    var values by remember { mutableStateOf(categories) }
    var newValue by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Kelola kategori") }, text = {
        Column {
            OutlinedTextField(newValue, { newValue = it }, Modifier.fillMaxWidth(), label = { Text("Kategori baru") }, singleLine = true)
            TextButton(onClick = { if (newValue.isNotBlank() && values.none { it.equals(newValue.trim(), true) }) { values = values + newValue.trim(); newValue = "" } }) { Text("＋ Tambah kategori") }
            values.forEach { item ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(item, Modifier.weight(1f))
                    IconButton(onClick = { values = values - item }) { Icon(Icons.Default.DeleteOutline, "Hapus", tint = Expense) }
                }
            }
        }
    }, confirmButton = { TextButton(onClick = { onSave(values); onDismiss() }) { Text("Simpan") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } })
}

@Composable
fun BudgetDialog(current: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var value by remember { mutableStateOf(current) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Anggaran bulanan") }, text = {
        OutlinedTextField(value, { value = it.filter(Char::isDigit) }, label = { Text("Batas anggaran (Rp)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
    }, confirmButton = { TextButton(onClick = { onSave(value); onDismiss() }) { Text("Simpan") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } })
}

private fun xml(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&apos;")
private fun decodeXml(s: String) = s.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'")

private fun readWorkbook(input: java.io.InputStream): List<Tx> {
    var sheet = ""
    ZipInputStream(input).use { zip ->
        var entry = zip.nextEntry
        while (entry != null) { if (entry.name == "xl/worksheets/sheet1.xml") sheet = zip.readBytes().toString(Charsets.UTF_8); entry = zip.nextEntry }
    }
    return Regex("<row[^>]*>(.*?)</row>").findAll(sheet).drop(1).mapNotNull { match ->
        val cells = Regex("<t>(.*?)</t>").findAll(match.groupValues[1]).map { decodeXml(it.groupValues[1]) }.toList()
        if (cells.size >= 6) Tx(0, cells[1], cells[2].toLongOrNull() ?: 0L, cells[3], cells[4], cells[5]) else null
    }.toList()
}

private fun writeWorkbook(out: java.io.OutputStream, rows: List<Tx>) {
    val all = listOf(listOf("ID", "Nama", "Jumlah_Rp", "Jenis", "Kategori", "Tanggal")) +
        rows.map { listOf(it.id.toString(), it.title, it.amount.toString(), it.type, it.category, it.date) }
    val sheet = buildString {
        append("<?xml version=\"1.0\" encoding=\"UTF-8\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>")
        all.forEachIndexed { ri, row ->
            append("<row r=\"${ri + 1}\">")
            row.forEachIndexed { ci, value ->
                val col = ('A'.code + ci).toChar()
                append("<c r=\"$col${ri + 1}\" t=\"inlineStr\"><is><t>${xml(value)}</t></is></c>")
            }
            append("</row>")
        }
        append("</sheetData></worksheet>")
    }
    ZipOutputStream(out).use { z ->
        fun entry(name: String, content: String) { z.putNextEntry(ZipEntry(name)); z.write(content.toByteArray(Charsets.UTF_8)); z.closeEntry() }
        entry("[Content_Types].xml", """<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>""")
        entry("_rels/.rels", """<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>""")
        entry("xl/workbook.xml", """<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Transaksi" sheetId="1" r:id="rId1"/></sheets></workbook>""")
        entry("xl/_rels/workbook.xml.rels", """<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>""")
        entry("xl/worksheets/sheet1.xml", sheet)
    }
}
